#!/bin/bash

echo "Verifying NX Demo Setup..."
echo ""

if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

echo "Building all projects..."
npx nx run-many --target=build --all

echo ""
echo "Testing cache..."
npx nx build web-app

echo ""
echo "Running tests..."
npx nx run-many --target=test --all

echo ""
echo "Setup verification complete!"
echo ""
echo "Your demo is ready. See DEMO.md for the 1-minute script."
