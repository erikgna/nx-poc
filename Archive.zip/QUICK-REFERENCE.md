# NX Demo Quick Reference

## Project Structure
- **2 Apps**: web-app, mobile-app
- **2 Libs**: utils (base), api-client (depends on utils)
- All apps depend on both libraries

## Before Demo
```bash
npm install
npx nx build web-app
```

## 1-Minute Demo Commands

### 1. Show Project Graph (Slide 2)
```bash
npx nx graph
```
Opens browser with interactive dependency graph

### 2. Caching Demo (Slide 5)
```bash
rm -rf dist
npx nx build web-app
npx nx build web-app
```
First build: compiles
Second build: instant cache hit

### 3. Affected Demo (Slide 1)
```bash
echo "export const version = '2.0.0';" >> libs/utils/src/index.ts
npx nx affected:graph
```
Shows only affected projects

### 4. Parallel Execution (Slide 4)
```bash
npx nx run-many --target=test --all
```
Runs all tests in parallel

## Talking Points Map

| Slide | Command | Concept |
|-------|---------|---------|
| Slide 1 | affected:graph | Monorepo Tax solved |
| Slide 2 | graph | Project Graph visualization |
| Slide 4 | run-many | Task Pipeline |
| Slide 5 | build (2x) | Computation Caching |

## Reset Between Demos
```bash
rm -rf dist node_modules/.cache
git checkout libs/utils/src/index.ts
```
