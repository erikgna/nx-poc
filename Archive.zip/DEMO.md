# 1-Minute NX Live Demo Script

## Setup (Before Demo)
```bash
npm install
```

## Demo Flow (60 seconds)

### 1. Show the Project Graph (15 seconds)
```bash
nx graph
```
Point out:
- Two apps (web-app, mobile-app)
- Two libraries (utils, api-client)
- Dependency arrows showing the DAG
- This is the "Brain in the Machine" from Slide 2

### 2. Demonstrate Computation Caching (20 seconds)
```bash
nx build web-app
```
Wait for build to complete, then run again:
```bash
nx build web-app
```
Point out:
- First build: takes time (compiling TypeScript)
- Second build: instant cache hit (100ms)
- This is "The Gift of Perfect Memory" from Slide 5

### 3. Show Affected Commands (15 seconds)
```bash
echo "export const version = '2.0.0';" >> libs/utils/src/index.ts
nx affected:graph
```
Point out:
- Changed only utils library
- Graph shows all affected projects (utils, api-client, both apps)
- Only rebuild what changed
- This solves "The Monorepo Tax" from Slide 1

### 4. Parallel Execution (10 seconds)
```bash
nx run-many --target=test --all
```
Point out:
- All tests run in parallel
- Task Pipeline ensures correct order
- This is "The Choreography of Action" from Slide 4

## Key Talking Points
- Project Graph: NX understands dependencies automatically
- Caching: Never rebuild the same thing twice
- Affected: Only work on what changed
- Parallel: Maximum efficiency

## Reset Demo (if needed)
```bash
rm -rf dist node_modules/.cache
```
